// Renders the homepage featured cards from api/featured.php.
// If the request fails, the static cards already in the HTML stay in place.
(function () {
  var grid = document.getElementById('featured-grid');
  if (!grid) return;
  var apiBase = grid.getAttribute('data-api-base') || '../api/';
  var assetBase = grid.getAttribute('data-asset-base') || '../';

  var TYPES = { boarding: 'Boarding house', guesthouse: 'Guesthouse' };
  var UNITS = { per_bed_month: '/ bed / month', per_night: '/ night', per_month: '/ month' };

  function el(tag, cls, text) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text !== undefined) n.textContent = text;
    return n;
  }

  function commuteText(c) {
    if (!c) return 'Commute estimate: not measured yet';
    var km = (c.distance_m / 1000).toFixed(1);
    var min = Math.round(c.duration_s / 60);
    return c.destination + ' · ' + km + ' km · about ' + min + ' min by ' +
      c.mode + ' (route-based estimate)';
  }

  function card(l) {
    var isDemo = /^\[Demo\]/.test(l.name);
    var art = el('article', 'listing-card');

    var wrap = el('div', 'listing-image-wrap');
    if (l.photo) {
      var img = el('img', 'listing-image');
      img.src = assetBase + l.photo;
      img.alt = l.photo_caption || l.name;
      img.loading = 'lazy';
      wrap.appendChild(img);
    }
    art.appendChild(wrap);

    var body = el('div', 'listing-body');
    var badges = el('div', 'listing-badges');
    if (isDemo) badges.appendChild(el('span', 'badge badge-demo', 'Demo data'));
    badges.appendChild(el('span', 'badge badge-type', TYPES[l.type] || l.type));
    badges.appendChild(el('span', l.is_verified ? 'badge badge-type' : 'badge badge-unverified',
      l.is_verified ? 'Admin-reviewed' : 'Not verified'));
    body.appendChild(badges);

    body.appendChild(el('h3', '', l.name));
    var fac = l.facilities.join(' · ') + (isDemo ? ' (sample text)' : '');
    body.appendChild(el('p', 'text-small text-muted', fac));
    body.appendChild(el('p', 'text-small text-muted commute-note', commuteText(l.commute)));

    var priceRow = el('div', 'listing-price');
    var price = el('span', 'price', 'K' + Math.round(l.price).toLocaleString('en-US') + ' ');
    price.appendChild(el('small', '', (UNITS[l.price_unit] || '') + (isDemo ? ' (sample)' : '')));
    priceRow.appendChild(price);
    var btn = el('span', 'btn btn-secondary btn-disabled', 'Detail page — Milestone 2');
    btn.setAttribute('aria-disabled', 'true');
    priceRow.appendChild(btn);
    body.appendChild(priceRow);

    art.appendChild(body);
    return art;
  }

  fetch(apiBase + 'featured.php', { headers: { Accept: 'application/json' } })
    .then(function (r) { return r.json(); })
    .then(function (data) {
      if (!data.ok || !data.listings.length) return;
      grid.textContent = '';
      data.listings.forEach(function (l) { grid.appendChild(card(l)); });
    })
    .catch(function () { /* keep static fallback cards */ });
})();
