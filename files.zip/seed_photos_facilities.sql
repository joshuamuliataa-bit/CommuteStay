-- Moves the three homepage photos and facilities into the database.
-- Run in phpMyAdmin (database: commutestay) via the SQL or Import tab.
-- Matches properties by name, so no ids are assumed. Safe to run twice.
USE commutestay;

-- Photos (files must exist in assets/images/: listing-1.jpg, -2.jpg, -3.jpg)
INSERT INTO property_photos (property_id, file_path, caption, is_primary, sort_order)
SELECT p.id, 'assets/images/listing-1.jpg',
       'Grey single-storey boarding house with orange window frames and a covered entrance', 1, 0
FROM properties p WHERE p.name LIKE '%Fairview Student Lodge%'
  AND NOT EXISTS (SELECT 1 FROM property_photos x WHERE x.property_id = p.id AND x.file_path = 'assets/images/listing-1.jpg');

INSERT INTO property_photos (property_id, file_path, caption, is_primary, sort_order)
SELECT p.id, 'assets/images/listing-2.jpg',
       'Single-storey guesthouse with a paved courtyard, trimmed hedges and a water tank', 1, 0
FROM properties p WHERE p.name LIKE '%Rhodes Park Guest Annex%'
  AND NOT EXISTS (SELECT 1 FROM property_photos x WHERE x.property_id = p.id AND x.file_path = 'assets/images/listing-2.jpg');

INSERT INTO property_photos (property_id, file_path, caption, is_primary, sort_order)
SELECT p.id, 'assets/images/listing-3.jpg',
       'Shared student room with bunk beds, wooden wardrobes and a study desk by the window', 1, 0
FROM properties p WHERE p.name LIKE '%Cathedral Hill Shared Units%'
  AND NOT EXISTS (SELECT 1 FROM property_photos x WHERE x.property_id = p.id AND x.file_path = 'assets/images/listing-3.jpg');

-- Facilities (taken from the existing card text; unique key stops duplicates)
INSERT IGNORE INTO property_facilities (property_id, facility)
SELECT p.id, f.facility FROM properties p
JOIN (SELECT 'Shared rooms' AS facility UNION ALL SELECT 'Wi-Fi' UNION ALL SELECT 'Borehole water') f
WHERE p.name LIKE '%Fairview Student Lodge%';

INSERT IGNORE INTO property_facilities (property_id, facility)
SELECT p.id, f.facility FROM properties p
JOIN (SELECT 'Private en-suite' AS facility UNION ALL SELECT 'Parking' UNION ALL SELECT 'Solar backup') f
WHERE p.name LIKE '%Rhodes Park Guest Annex%';

INSERT IGNORE INTO property_facilities (property_id, facility)
SELECT p.id, f.facility FROM properties p
JOIN (SELECT '2-4 bed units' AS facility UNION ALL SELECT 'Study area' UNION ALL SELECT 'Guarded gate') f
WHERE p.name LIKE '%Cathedral Hill Shared Units%';

-- Check: should return 3 photos and 9 facilities
SELECT (SELECT COUNT(*) FROM property_photos) AS photos,
       (SELECT COUNT(*) FROM property_facilities) AS facilities;
